const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const { exec } = require("child_process");

const app = express();

app.use(cors());
app.use(bodyParser.json());

const routes = require('./routes/routes');
app.use('/api/wizard',routes);

const PORT = 4001;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
