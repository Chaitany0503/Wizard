import React from 'react'

export default function Navbar() {
  return (
    <div className='Navbar'>
      <button>Run Code</button>
    </div>
  )
}
